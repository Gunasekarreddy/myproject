from flask import Flask, request, render_template
import numpy as np 
import string
from nltk.corpus import stopwords
import pandas as pd 
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.tree import DecisionTreeClassifier
from sklearn.feature_extraction.text import TfidfTransformer,TfidfVectorizer
from sklearn.pipeline import Pipeline

app = Flask(__name__)

# importing the dataset
df = pd.read_csv(r"C:\Users\zerobroz\Desktop\AI_Phase4\data_set\dialogs.txt", sep='\t')

#add column names
df.columns=['Questions','Answers']

# Function for converting upper to lower case
def cleaner(x):
    return [''.join([a for a in x if a not in string.punctuation]).lower()]

# Load your pre-trained pipeline model
Pipe = Pipeline([
    ('bow', CountVectorizer(analyzer=cleaner)),
    ('tfidf', TfidfTransformer()),
    ('classifier', DecisionTreeClassifier())
])

# Load your pre-trained model weights
Pipe.fit(df['Questions'], df['Answers'])

# Define route for the home page
@app.route('/')
def index():
    return render_template('index.html')

# Define route for processing user input and generating chatbot response
@app.route('/get_response', methods=['POST'])
def get_response():
    user_input = request.form['user_input']
    response = Pipe.predict([user_input])[0]
    return render_template('index.html', user_input=user_input, response=response)

if __name__ == '__main__':
    app.run(debug=True)